## [Jupyter code c

You define Jupyter-like code cells within Python code using a `# %%` comment:

```
# %%
msg = "Hello World"
print(msg)

# %%
msg = "Hello again"
print(msg)
```