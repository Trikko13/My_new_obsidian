# My_obsidian

Tester

a cool edit indeed

rly? e

its Exxcaldraw now here

https://habr.com/ru/articles/843288/ how to use