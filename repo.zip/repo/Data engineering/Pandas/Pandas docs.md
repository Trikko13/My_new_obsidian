10min quickstart - https://pandas.pydata.org/docs/user_guide/10min.html
