Greenplum - СУБД на Postgres, MPP arch Shared Nothing.
Master Instance - т.н. Инстанс - координатор и входная точка в кластере.
Master host - сервер, на котором Инстанс .
Secondary instance - резеверный
Primary segment instance - Инстанс Посгрес, являющийся одним из сегментов.